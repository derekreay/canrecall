library(testthat)
library(canrecall)

test_check("canrecall")
